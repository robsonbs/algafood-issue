package br.dev.robsonbs.livraria.domain.models;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.math.BigDecimal;

@Entity
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Book {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @EqualsAndHashCode.Include
  private Long id;
  
  private String name;
  private BigDecimal value;
  private String author;
  private String ISBN;
  private String description;
  private String image;
  private transient int quantity;
  @ManyToOne
  private Category category;
  
}
