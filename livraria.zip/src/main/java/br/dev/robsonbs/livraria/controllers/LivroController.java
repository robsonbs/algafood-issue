package br.dev.robsonbs.livraria.controllers;

import br.dev.robsonbs.livraria.domain.models.Book;
import br.dev.robsonbs.livraria.repotories.LivroRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/livros")
public class LivroController {
  
  @Autowired
  private LivroRepository livroRepository;
  
  @GetMapping
  public List<Book> list() {
    return livroRepository.findAll();
  }
  
  @GetMapping("/{livro_id}")
  public Book show(@PathVariable("livro_id") Long id) {
    return livroRepository.findById(id).orElse(null);
  }
  
  @PostMapping
  public Book create(@RequestBody Book book) {
    return livroRepository.save(book);
  }
  
  @PutMapping("/{livro_id}")
  public Book update(@PathVariable("livro_id") Long id, @RequestBody Book book) {
    Book foundBook = livroRepository.findById(id).orElse(null);
    if (foundBook != null) {
      BeanUtils.copyProperties(book, foundBook, "id");
      return livroRepository.save(foundBook);
    }
    return null;
  }
  
  @DeleteMapping("/{livro_id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void remove(@PathVariable("livro_id") Long id) {
    Book foundBook = livroRepository.findById(id).orElse(null);
    if (foundBook != null) { livroRepository.delete(foundBook);}
  }
}
